npm install


npm start

